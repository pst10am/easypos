package app_admin;

import javax.swing.JPanel;

public class PanelTbOrder extends JPanel {

}
