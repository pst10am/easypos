package app_admin;

public interface IxFloor {

	void selectedTable(CmpTable cmptbl);
}
