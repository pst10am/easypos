package app_admin;

import model.TxOptItem;

interface IxOpi {
	void defaultChangeTo(TxOptItem dopi);
}
