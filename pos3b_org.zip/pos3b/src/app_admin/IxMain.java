package app_admin;

import java.awt.Frame;

public interface IxMain {
	public Frame getFrame();
}
