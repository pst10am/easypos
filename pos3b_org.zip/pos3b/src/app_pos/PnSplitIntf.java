package app_pos;

public interface PnSplitIntf {

	public void showScrMain();
}
