package app_pos;

import model.TxSctTable;

public interface PnTxSctIntf {

	public void tableSelected(TxSctTable tbl1);
}
