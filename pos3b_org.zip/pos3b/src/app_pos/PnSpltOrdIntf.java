package app_pos;

public interface PnSpltOrdIntf {

	public void headClick(PnSpltOrd spOrd, boolean moveItem);
}
