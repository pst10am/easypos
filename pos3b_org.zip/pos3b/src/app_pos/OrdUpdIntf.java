package app_pos;

import java.awt.Dialog;

public interface OrdUpdIntf {

	public Dialog getDialog();
	public void updateOrderInfo();
}
