package app_pos;

public enum KeyInputType {
	Any, Integer, Double, CreditCard, CVV 
}
