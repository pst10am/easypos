package app_pos;

import model.TxFdItem;

public interface PnMenuIntf {

	public void menuItemSelected(TxFdItem fdItm);
}
