package refx;

public enum CCCapture {

	None, Success, Fail;
}
