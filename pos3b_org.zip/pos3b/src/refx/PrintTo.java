package refx;

public enum PrintTo {
	Kitchen, Packing, Cashier
}
