package refx;

public enum OptionType {
	Single, Multiple
}
