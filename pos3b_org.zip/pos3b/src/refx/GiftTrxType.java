package refx;

public enum GiftTrxType {
	NA, Activate, Redeem, Refill, Void;
}
