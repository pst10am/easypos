package refx;

public enum ButtonType {
	Normal, Ok, Cancel
}
