package refx;

public enum OrderItemType {
	NA, Item, OpenItem, Line, Discount, Charge
}
