package refx;

public enum OrderType {
	NA, DineIn, ToGo
}
