package refx;

public enum SlipType {
	
	Packing, Cashier
}
