package refx;

public enum ClockType {

	In, Out, NA
}
