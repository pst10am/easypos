package refx;

public enum DCType {
	Discount, Charge
}
