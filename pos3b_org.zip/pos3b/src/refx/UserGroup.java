package refx;

public enum UserGroup {
	Waiter, Kitchen, Manager
}
