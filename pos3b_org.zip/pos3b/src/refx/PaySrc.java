package refx;

public enum PaySrc {
	
	NA, Order, Gift;
	
	public static final int size = 3;
}
