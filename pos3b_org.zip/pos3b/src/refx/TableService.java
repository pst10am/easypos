package refx;

public enum TableService {
	Ready, Service, Checked, Paid
}
