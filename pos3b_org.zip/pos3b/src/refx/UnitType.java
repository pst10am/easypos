package refx;

public enum UnitType {
	US, Metric
}
