package refx;

public enum ToGoType {
	NA, Delivery, PickUp, Waiting
}
