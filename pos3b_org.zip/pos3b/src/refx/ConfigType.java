package refx;

public enum ConfigType {
	FREETEXT, MULTIPLE, SINGLE
}
