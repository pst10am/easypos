package model;

public class RptFld {
	public int count;
	public double amount;
}