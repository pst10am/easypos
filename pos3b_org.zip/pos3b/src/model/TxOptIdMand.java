package model;

public class TxOptIdMand {

	public int optId;
	public boolean optMand;
	
	public TxOptIdMand(int _id, boolean _mand) {
		optId = _id;
		optMand = _mand;
	}
}
