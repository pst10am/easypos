package resrc;

import java.awt.Font;

public class StdFont {
	
	private static String fntName = "Tahoma";
	
	public static final Font Fnt12 = new Font(fntName, Font.PLAIN, 12);
	public static final Font Fnt14 = new Font(fntName, Font.PLAIN, 14);
	public static final Font Fnt16 = new Font(fntName, Font.PLAIN, 16);
	public static final Font Fnt18 = new Font(fntName, Font.PLAIN, 18);
	public static final Font Fnt20 = new Font(fntName, Font.PLAIN, 20);
	public static final Font Fnt22 = new Font(fntName, Font.PLAIN, 22);
	public static final Font Fnt24 = new Font(fntName, Font.PLAIN, 24);
	public static final Font Fnt26 = new Font(fntName, Font.PLAIN, 26);
	public static final Font Fnt28 = new Font(fntName, Font.PLAIN, 28);
	public static final Font Fnt30 = new Font(fntName, Font.PLAIN, 30);
	public static final Font Fnt32 = new Font(fntName, Font.PLAIN, 32);

	public static final Font Fnt14B = new Font(fntName, Font.BOLD, 14);
	public static final Font Fnt16B = new Font(fntName, Font.BOLD, 16);
	public static final Font Fnt18B = new Font(fntName, Font.BOLD, 18);
	public static final Font Fnt20B = new Font(fntName, Font.BOLD, 20);
	public static final Font Fnt22B = new Font(fntName, Font.BOLD, 22);
	public static final Font Fnt32B = new Font(fntName, Font.BOLD, 32);

	public static final Font Fnt14I = new Font(fntName, Font.PLAIN, 16);
	
	// monospaced
	
	private static String fntNameMono = "monospaced";
	
	public static final Font Fnt12Mono = new Font(fntNameMono, Font.PLAIN, 12);
	public static final Font Fnt14Mono = new Font(fntNameMono, Font.PLAIN, 14);
	public static final Font Fnt16Mono = new Font(fntNameMono, Font.PLAIN, 16);
	public static final Font Fnt18Mono = new Font(fntNameMono, Font.PLAIN, 18);
}
