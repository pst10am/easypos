package resrc;

import java.io.File;

import resrc.ResUtil;

final class SysCleanUp {
	private SysCleanUp() {}

}
